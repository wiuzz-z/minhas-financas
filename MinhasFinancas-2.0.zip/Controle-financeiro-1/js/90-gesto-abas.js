/* ===== 0.7 · Arrastar para o lado troca de aba (só celular; nenhum dado ou cálculo muda aqui) =====
   Arrastar para a ESQUERDA vai para a aba seguinte da barra de baixo; para a DIREITA, para a anterior.
   - A tela acompanha o dedo (só o conteúdo; a barra de baixo fica parada). Passou de ~28% da largura, ou foi um deslize rápido: troca.
     Senão volta para o lugar com uma mola suave. Na primeira e na última aba o conteúdo "resiste" e volta.
   - A troca de verdade é o toque na própria barra de baixo (mesmas regras de plano/bloqueio de sempre); só a animação é nova.
   - Não dispara: no computador; começando na borda esquerda (ali é o gesto de voltar); em campo de texto ou com teclado aberto;
     em barras que rolam para o lado (sub-abas, dias, gráficos); em Lançamentos sobre a lista/resumo (ali o arrastar troca o mês);
     com janela aberta (Configurações, editor, confirmação, bloqueio) ou no modo organizar (arrastar blocos).
   - Respeita "reduzir movimento" do aparelho e Animações desligadas em Aparência (troca direto, sem animar).
   O CSS fica em css/86-gesto-abas.css. Para um elemento nunca iniciar o gesto, basta pôr o atributo data-nosw nele. */
/* ===== 1.0 · Arrastar para o lado troca de SUBABA (só celular; nenhum dado ou cálculo muda aqui) =====
   Arrastar para a ESQUERDA vai para a subaba seguinte; para a DIREITA, para a anterior. Vale só onde há subabas:
     Investimentos (Resumo, Posição, Proventos, Análise), Contas (Geral, Compras, Simular) e Análises (Mês e Ano).
   As abas principais da barra de baixo NÃO trocam mais por arrasto (só pelo toque).
   - A tela acompanha o dedo (só o conteúdo; a barra de baixo fica parada). Passou de ~28% da largura, ou foi um deslize rápido: troca.
     Senão volta para o lugar com uma mola suave. Na primeira e na última subaba o conteúdo "resiste" e volta.
   - A troca de verdade é o toque no botão da própria subaba (mesmas regras de plano/bloqueio de sempre); só a animação é nova.
     Durante o deslize os cartões não fazem a entrada em cascata vertical (era o "desce e sobe"): só o movimento lateral.
   - Não dispara: no computador; começando na borda esquerda (ali é o gesto de voltar); em campo de texto ou com teclado aberto;
     em barras que rolam para o lado (dias, gráficos); com janela aberta (Configurações, editor, confirmação, bloqueio)
     ou no modo organizar (arrastar blocos).
   - Respeita "reduzir movimento" do aparelho e Animações desligadas em Aparência (troca direto, sem animar).
   O CSS fica em css/86-gesto-abas.css. Para um elemento nunca iniciar o gesto, basta pôr o atributo data-nosw nele. */
(function () {
  const root = document.documentElement;
  const BORDA = 24;                      // px da borda esquerda reservados ao gesto de voltar
  const parado = () => (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) || root.dataset.mfanim === '0';
  const celular = () => !root.classList.contains('mf-desk') && !(window.mfIsDesk && mfIsDesk());
  // subabas de cada tela: a barra de seleção (.mf-seg) tem um botão por subaba; o que está ligado tem a classe "on"
  const SUBS = { add: 'data-addmode', inv: 'data-invmode', mais: 'data-ctmode', anal: 'data-anmode' };
  const subabas = () => {
    const attr = SUBS[root.dataset.tab]; if (!attr) return null;
    const bs = [...document.querySelectorAll(`#app .mf-seg [${attr}]`)].filter(b => b.offsetParent);
    const i = bs.findIndex(b => b.classList.contains('on'));
    return bs.length > 1 && i >= 0 ? { bs, i } : null;
  };
  const app = () => document.getElementById('app');
  const SEMGESTO = 'input,textarea,select,[contenteditable="true"],[data-nosw],[data-diastrip],[data-pvcalsw],[data-pvsw],.mf-osc-svg,.dash-calendar-grid';
  const JANELAS = '#mf-lk,#mf-confirm,#mf-lock,.quick-backdrop,#cb-pop,#mf-note';
  let g = null, timer = 0;

  function rolaLado(el) {
    for (let e = el; e && e !== document.body && e.id !== 'app'; e = e.parentElement) {
      const o = getComputedStyle(e).overflowX;
      if ((o === 'auto' || o === 'scroll') && e.scrollWidth > e.clientWidth + 2) return true;
    }
    return false;
  }
  function bloqueado(t) {
    if (!t || !t.closest) return true;
    if (root.classList.contains('mf-locked') || document.body.classList.contains('org-on')) return true;
    const cfg = document.getElementById('mf-cfg'); if (cfg && !cfg.hidden) return true;
    if (document.querySelector(JANELAS)) return true;
    const ae = document.activeElement; if (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) return true;
    if (!t.closest('#app')) return true;                         // só o conteúdo da tela, não a barra de baixo nem o topo fixo
    if (t.closest(SEMGESTO)) return true;
    return rolaLado(t);
  }
  function limpar() {
    const a = app(); if (!a) return;
    clearTimeout(timer); a.classList.remove('mf-sw-drag');
    a.style.transform = ''; a.style.transition = '';
  }
  function ir(destino, dir) {
    if (!destino) return;
    const y = scrollY;                                            // os botões das subabas mandam a página para o topo; no arrasto ela fica onde estava
    destino.click();                                              // a troca de verdade, igual ao toque no botão da subaba
    if (y > 0 && Math.abs(scrollY - y) > 1) scrollTo(0, y);       // mesmo quadro: ninguém vê a tela pular
    try { if (navigator.vibrate) navigator.vibrate(6); } catch (e) { }
    const a = app(); if (!a || parado()) return;
    // tira também a "mf-tab-in" (animação de trocar de aba): se ficasse, ao terminar a entrada lateral ela RECOMEÇARIA por baixo
    // (desce 18px e sobe) = o "desce e sobe" logo depois de a subaba chegar.
    a.classList.remove('mf-tab-in', 'mf-sw-l', 'mf-sw-r'); void a.offsetWidth;
    // a cascata dos cartões (js/99) também sai: se ficasse, ao fim do deslize ela COMEÇAVA (cartões descendo ~30px e subindo) = o "pulo" depois da troca
    semCascata(a);
    a.classList.add(dir < 0 ? 'mf-sw-l' : 'mf-sw-r', 'mf-sw-q');   // entra pelo lado oposto ao do deslize; "mf-sw-q" segura as entradas verticais até o próximo toque
    clearTimeout(a.__swT); a.__swT = setTimeout(() => { a.classList.remove('mf-sw-l', 'mf-sw-r'); semCascata(a); }, 520);
  }
  function semCascata(a) { a.querySelectorAll('.mf-stagger').forEach(e => { e.classList.remove('mf-stagger'); e.style.animationDelay = ''; }); }
  // qualquer toque/clique de verdade volta ao normal (a troca por arrasto não gera clique; o clique do próprio ir() acontece antes de "mf-sw-q" entrar)
  document.addEventListener('click', () => { const a = app(); if (a) a.classList.remove('mf-sw-q'); }, true);

  document.addEventListener('touchstart', e => {
    g = null;
    if (!celular() || e.touches.length !== 1) return;
    const t = e.touches[0]; if (t.clientX <= BORDA || bloqueado(e.target)) return;
    const sb = subabas(); if (!sb) return;
    g = { x: t.clientX, y: t.clientY, y0: scrollY, ab: sb.bs, i: sb.i, est: 'espera', dx: 0, pts: [[performance.now(), t.clientX]] };
  }, { passive: true, capture: true });

  document.addEventListener('touchmove', e => {
    if (!g) return;
    if (e.touches.length > 1) { if (g.est === 'arrasto') limpar(); g = null; return; }
    const t = e.touches[0], dx = t.clientX - g.x, dy = t.clientY - g.y;
    if (g.est === 'espera') {
      // decide no PRIMEIRO movimento de verdade: o navegador só deixa cancelar a rolagem antes de ela começar; se o gesto esperasse mais,
      // a página já teria começado a rolar e seguiria o balanço vertical do dedo durante todo o arrasto.
      if (Math.hypot(dx, dy) < 3) return;
      if (Math.abs(dx) <= Math.abs(dy)) { g = null; return; }                               // mais vertical: rolagem normal
      g.est = 'arrasto'; g.x = t.clientX - Math.sign(dx) * Math.min(Math.abs(dx), 12); if (!parado()) { const a = app(); a && a.classList.add('mf-sw-drag'); }
    }
    if (e.cancelable) e.preventDefault();
    if (g.y0 !== undefined && Math.abs(scrollY - g.y0) > 1) scrollTo(0, g.y0);              // se alguma rolagem escapou, desfaz
    const x = t.clientX - g.x; g.dx = x;
    g.pts.push([performance.now(), t.clientX]); if (g.pts.length > 6) g.pts.shift();
    if (parado()) return;
    const w = root.clientWidth || 390, viz = g.ab[g.i + (x < 0 ? 1 : -1)];
    const px = viz ? x : x * 0.22;                                // sem subaba do lado: resiste
    const a = app(); if (!a) return;
    cancelAnimationFrame(g.raf);
    g.raf = requestAnimationFrame(() => { a.style.transition = 'none'; a.style.transform = `translate3d(${px}px,0,0)`; });
  }, { passive: false, capture: true });

  function fim() {
    if (!g) return; const s = g; g = null;
    if (s.est !== 'arrasto') return;
    cancelAnimationFrame(s.raf);
    const dx = s.dx, dir = dx < 0 ? -1 : 1, w = root.clientWidth || 390, destino = s.ab[s.i - dir]; // esquerda (dir<0) = próxima
    const p = s.pts, ult = p[p.length - 1], ref = p.find(q => ult[0] - q[0] <= 110) || p[0];
    const v = ult[0] > ref[0] ? (ult[1] - ref[1]) / (ult[0] - ref[0]) : 0;               // px por ms
    const vale = !!destino && (Math.abs(dx) > w * 0.28 || (Math.abs(v) > 0.45 && Math.abs(dx) > 36)) && (v === 0 || Math.sign(v) === dir);
    const a = app(); if (!a) return;
    if (parado()) { limpar(); if (vale) ir(destino, dir); return; }
    if (vale) {
      a.style.transition = 'transform .16s cubic-bezier(.4,0,1,1)';
      a.style.transform = `translate3d(${dir * w * 0.3}px,0,0)`;
      timer = setTimeout(() => { limpar(); ir(destino, dir); }, 150);
    } else {
      a.style.transition = 'transform .38s cubic-bezier(.22,1,.36,1)';
      a.style.transform = 'translate3d(0,0,0)';
      timer = setTimeout(limpar, 400);
    }
  }
  document.addEventListener('touchend', fim, { passive: true, capture: true });
  document.addEventListener('touchcancel', () => { if (g && g.est === 'arrasto') limpar(); g = null; }, { passive: true, capture: true });
})();

/* Editar tela (1.15) — personalizar a tela em cima da própria tela, como os widgets do celular.
   Em modo edição cada bloco ganha contorno tracejado e um "−" no canto (ocultar; nos blocos adicionados, remover).
   Segurar e arrastar muda a ordem (no computador, é só arrastar); tocar no bloco abre largura, setas e troca de aba.
   No fim da tela, o quadro "+" abre a folha "Adicionar blocos" (widgets com prévia e blocos ocultos para trazer de volta).
   Tudo é rascunho: só "Pronto" grava (save). "Cancelar" devolve exatamente o que estava.
   Mesmo esqueleto de blocos do app (S.lay.o / h / w / wg / mvt), por aparelho: celular e computador separados.
   Também aplica o estilo "Compacto" das telas (S.lay.dens = 'c'). */
(function () {
 'use strict';
 if (typeof MF_DEV_K !== 'undefined' && !MF_DEV_K.includes('dens')) MF_DEV_K.push('dens');
 const KS = ['o', 'h', 'w', 'wg', 'mvt'];
 let ed = null, dg = null, semClique = 0, sheetAba = 'res', busca = '', sheetSel = null;
 const L = () => S.lay || (S.lay = {});
 const ehWg = id => /^p_wg~\d+$/.test(id);
 const idDe = el => String(el.dataset.bk || '').split('|')[1] || '';
 const nomeTela = t => ((S.lay || {}).tn || {})[t] || (typeof MF_TTL !== 'undefined' && MF_TTL[t]) || t;
 const desk = () => !!(window.mfIsDesk && mfIsDesk());
 function snap() { const l = L(), o = {}; KS.forEach(k => { if (l[k] !== undefined) o[k] = JSON.parse(JSON.stringify(l[k])); }); return o; }
 function volta(b) { const l = L(); KS.forEach(k => { if (k in b) l[k] = b[k]; else delete l[k]; }); }

 /* ---------- estilo Compacto ---------- */
 const applyOrig = applyLay;
 applyLay = function () {
  const r = applyOrig.apply(this, arguments);
  try {
   const root = document.documentElement, c = (S.lay || {}).dens === 'c';
   if (c) { root.setAttribute('data-mfdens', 'c'); root.style.setProperty('--card-pad', '11px'); root.style.setProperty('--layout-gap', '9px'); }
   else root.removeAttribute('data-mfdens');
  } catch (e) { }
  return r;
 };

 /* ---------- abrir / sair ---------- */
 window.mfEdOn = () => !!ed;
 window.mfEdOpen = function (t) {
  if (ed) return;
  const c = document.getElementById('mf-cfg'); if (c && !c.hidden && window.mfCfgClose) mfCfgClose();
  if (t && t !== tab) { tab = t; window.__mfLastTab = null; }
  ed = { t: tab, bak: snap(), sel: '' };
  document.documentElement.classList.add('mf-ed-on');
  barra(); draw(); scrollTo(0, 0); requestAnimationFrame(() => scrollTo(0, 0));
 };
 function sair(ok) {
  if (!ed) return;
  if (ok) save(); else volta(ed.bak);
  ed = null; dg = null; fechaSheet();
  document.documentElement.classList.remove('mf-ed-on');
  const b = document.getElementById('mf-ed-bar'); if (b) b.remove();
  draw();
  if (window.mfToast) mfToast(ok ? 'Tela salva ✓' : 'Alterações descartadas');
 }
 window.mfEdClose = sair;
 function muda(f, sel) { f(L()); if (sel !== undefined) ed.sel = sel; draw(); }
 function barra() {
  let b = document.getElementById('mf-ed-bar');
  if (!b) { b = document.createElement('div'); b.id = 'mf-ed-bar'; document.body.appendChild(b); }
  b.innerHTML = `<div class="mf-ed-tt"><small>Editando</small><b>${escH(nomeTela(ed.t))}</b></div><button type="button" class="mf-ed-bt" data-edno="1">Cancelar</button><button type="button" class="mf-ed-bt ok" data-edok="1">Pronto</button>`;
 }

 /* ---------- depois de cada desenho: contorno, "−", barra do bloco escolhido e o quadro "+" ---------- */
 function blocos() { return [...document.querySelectorAll('#app [data-bk]')].filter(e => !e.parentElement.closest('#app [data-bk]')); }
 function barraBloco(id) {
  const w = (L().w || {})[id] || '', larg = [['', 'Padrão'], ['f', 'Inteira'], ['h', 'Meia']].concat(desk() ? [['t', 'Um terço']] : []);
  let aba = '';
  if (ehWg(id)) {
   /* 1.16: bloco adicionado ganha Tamanho e Modelo */
   const x = (mfWgList(ed.t) || []).find(y => y.id === id);
   if (x && window.MF_WG && MF_WG[x.k]) {
    const v = mfWgModelo(x.k, x.v), sz = mfWgSz(x.k, x.sz, v), M = MF_WG[x.k].m;
    aba = `<div class="mf-ed-ln"><small>Tamanho</small><span class="mf-ed-wd" role="group" aria-label="Tamanho">${MF_WG_SZ.filter(([k]) => k !== 'x' || mfWgMiniOk(x.k, v)).map(([k, t]) => `<button type="button" class="${sz === k ? 'on' : ''}" data-edwsz="${escH(id)}:${k}">${t}</button>`).join('')}</span></div>`
     + (M.length > 1 ? `<div class="mf-ed-ln"><small>Modelo</small><span class="mf-ed-wd" role="group" aria-label="Modelo">${M.map(([k, t]) => `<button type="button" class="${v === k ? 'on' : ''}" data-edwv="${escH(id)}:${k}">${escH(t)}</button>`).join('')}</span></div>` : '');
   }
  } else {
   const m = (L().mvt || {})[id], casa = (m && m.f) || ed.t, dest = (m && m.t) || casa, abas = tbs().filter(k => k === casa || k !== 'mais');
   aba = `<label class="mf-ed-ln"><small>Mostrar na aba</small><select data-edto="${escH(id)}">${abas.map(k => `<option value="${k}"${k === dest ? ' selected' : ''}>${escH(nomeTela(k))}</option>`).join('')}</select></label>`;
  }
  return `<div class="mf-ed-ctl mf-ed-tb"><div class="mf-ed-ln"><button type="button" class="mf-ed-ar" data-edmv="${escH(id)}:-1" aria-label="Subir">↑</button><button type="button" class="mf-ed-ar" data-edmv="${escH(id)}:1" aria-label="Descer">↓</button><span class="mf-ed-wd" role="group" aria-label="Largura">${larg.map(([v, x]) => `<button type="button" class="${w === v ? 'on' : ''}" data-edw="${escH(id)}:${v}">${x}</button>`).join('')}</span></div>${aba}</div>`;
 }
 function decora() {
  const app = document.getElementById('app'); if (!app) return;
  if (!ed) {
   if (!app.querySelector('.mf-ed-entry') && typeof org !== 'undefined' && !org && tbs().includes(tab)) app.insertAdjacentHTML('beforeend', `<div class="mf-ed-entry"><button type="button" data-edopen="${tab}">Editar tela</button></div>`);
   return;
  }
  if (tab !== ed.t) { ed.t = tab; barra(); }
  blocos().forEach(el => {
   const id = idDe(el); if (!id) return;
   el.classList.add('mf-ed-b'); if (id === ed.sel) el.classList.add('mf-ed-sel');
   el.insertAdjacentHTML('beforeend', `<button type="button" class="mf-ed-ctl mf-ed-x" data-edx="${escH(id)}" aria-label="${ehWg(id) ? 'Remover' : 'Ocultar'} este bloco">−</button>` + (id === ed.sel ? barraBloco(id) : ''));
  });
  const top = app.firstElementChild;
  const dica = `<div class="mf-ed-ctl mf-ed-hint">${desk() ? 'Arraste um bloco' : 'Segure um bloco e arraste'} para mudar a ordem. Toque nele para mudar a largura. O "−" esconde.</div>`;
  if (top && !top.matches('[data-bk]')) top.insertAdjacentHTML('afterend', dica); else app.insertAdjacentHTML('afterbegin', dica);
  app.insertAdjacentHTML('beforeend', `<button type="button" class="mf-ed-ctl mf-ed-add" data-edadd="1"><span aria-hidden="true">+</span><b>Adicionar bloco</b></button>`);
 }
 window.__mfAD.push(decora);
 /* a primeira tela é desenhada antes deste arquivo carregar: o botão "Editar tela" entra quando a página termina de carregar */
 document.addEventListener('DOMContentLoaded', () => { try { decora(); } catch (e) { console.warn('Editar tela', e); } });

 /* ---------- ordem ---------- */
 function ordem() { return ((typeof LAST !== 'undefined' && LAST[ed.t]) || blocos().map(idDe)).slice(); }
 function poe(id, alvo, depois) {
  const a = ordem().filter(x => x !== id), i = a.indexOf(alvo); if (i < 0) return;
  a.splice(depois ? i + 1 : i, 0, id);
  muda(l => { l.o = Object.assign({}, l.o || {}); l.o[ed.t] = a; }, id);
 }
 function sobeDesce(id, d) {
  const vis = blocos().map(idDe), i = vis.indexOf(id), j = i + d; if (i < 0 || j < 0 || j >= vis.length) return;
  poe(id, vis[j], d > 0);
 }

 /* ---------- cliques ---------- */
 document.addEventListener('click', e => {
  const t = e.target;
  const ab = t.closest && t.closest('[data-edopen]');
  if (ab && !ed) { e.preventDefault(); e.stopPropagation(); mfEdOpen(ab.dataset.edopen); return; }
  if (!ed) return;
  if (Date.now() - semClique < 450) { e.preventDefault(); e.stopPropagation(); return; }
  const c = t.closest('[data-edx],[data-edmv],[data-edw],[data-edadd],[data-edok],[data-edno],[data-edfecha],[data-edseg],[data-edaddk],[data-edshow],[data-edpick],[data-edsz],[data-edmod],[data-edvolta],[data-edwsz],[data-edwv]');
  if (c) {
   e.preventDefault(); e.stopPropagation();
   const d = c.dataset;
   if (d.edok) return sair(true);
   if (d.edno) return sair(false);
   if (d.edadd) return abreSheet();
   if (d.edfecha) return fechaSheet();
   if (d.edseg) { sheetAba = d.edseg; sheetSel = null; return pintaSheet(); }
   if (d.edpick) { const k = d.edpick; sheetSel = { k, sz: 'm', v: mfWgModelo(k) }; return pintaSheet(); }
   if (d.edvolta) { sheetSel = null; return pintaSheet(); }
   if (d.edsz && sheetSel) { sheetSel.sz = d.edsz; return pintaSheet(); }
   if (d.edmod && sheetSel) { sheetSel.v = d.edmod; if (sheetSel.sz === 'x' && !mfWgMiniOk(sheetSel.k, sheetSel.v)) sheetSel.sz = 'p'; return pintaSheet(); }
   if (d.edwsz || d.edwv) {
    const r = d.edwsz || d.edwv, k = r.lastIndexOf(':'), id = r.slice(0, k), val = r.slice(k + 1), campo = d.edwsz ? 'sz' : 'v';
    return muda(l => {
     const W = Object.assign({}, l.wg || {}); let sz = null;
     W[ed.t] = (W[ed.t] || []).map(x => {
      if (!x || x.id !== id) return x;
      const y = Object.assign({}, x, { [campo]: val });
      /* modelo sem número principal não fica em Mini: passa a Pequeno */
      if (campo === 'v' && y.sz === 'x' && !mfWgMiniOk(y.k, val)) y.sz = 'p';
      if (campo === 'sz' || y.sz !== x.sz) sz = y.sz;
      return y;
     });
     l.wg = W;
     /* Mini e Pequeno = meia largura (Mini no computador: um terço); Grande = inteira; Médio volta à largura padrão */
     if (sz !== null) { l.w = Object.assign({}, l.w || {}); const lg = mfWgLarg(sz); if (lg) l.w[id] = lg; else delete l.w[id]; }
    }, id);
   }
   if (d.edx) {
    const id = d.edx;
    if (ehWg(id)) muda(l => { const W = Object.assign({}, l.wg || {}); W[ed.t] = (W[ed.t] || []).filter(x => x && x.id !== id); if (!W[ed.t].length) delete W[ed.t]; l.wg = W; if (l.w) delete l.w[id]; }, '');
    else muda(l => { l.h = Object.assign({}, l.h || {}); l.h[id] = true; }, '');
    return;
   }
   if (d.edmv) { const k = d.edmv.lastIndexOf(':'); return sobeDesce(d.edmv.slice(0, k), +d.edmv.slice(k + 1)); }
   if (d.edw) { const k = d.edw.lastIndexOf(':'), id = d.edw.slice(0, k), v = d.edw.slice(k + 1); return muda(l => { l.w = Object.assign({}, l.w || {}); if (v) l.w[id] = v; else delete l.w[id]; }, id); }
   if (d.edaddk) {
    const k = d.edaddk, id = mfWgNovoId(), o = sheetSel && sheetSel.k === k ? sheetSel : { sz: 'm', v: mfWgModelo(k) }, it = { id, k }, sz = mfWgSz(k, o.sz, o.v), sub = mfWgSub(ed.t);
    if (sz !== 'm') it.sz = sz;
    if (o.v && o.v !== MF_WG[k].m[0][0]) it.v = o.v;
    if (sub) it.s = sub; /* 1.18: o bloco fica na subaba aberta agora */
    fechaSheet();
    muda(l => { const W = Object.assign({}, l.wg || {}); W[ed.t] = (Array.isArray(W[ed.t]) ? W[ed.t] : []).concat([it]); l.wg = W; const lg = mfWgLarg(sz); if (lg) { l.w = Object.assign({}, l.w || {}); l.w[id] = lg; } }, id);
    return mostra(id);
   }
   if (d.edshow) {
    const id = d.edshow, t = d.edshowt || ed.t; fechaSheet(); muda(l => { l.h = Object.assign({}, l.h || {}); l.h[id] = false; }, t === ed.t ? id : '');
    if (t !== ed.t) { if (window.mfToast) mfToast('O bloco voltou para ' + nomeTela(t)); return; }
    return mostra(id);
   }
   return;
  }
  if (t.closest('#mf-ed-sheet,#mf-ed-bar,select')) return;
  if (t.closest('[data-ctmode],[data-invmode],[data-anmode]')) return; // trocar de subaba continua valendo
  const b = t.closest('#app .mf-ed-b');
  if (b) { e.preventDefault(); e.stopPropagation(); const id = idDe(b); ed.sel = ed.sel === id ? '' : id; draw(); return; }
  if (t.closest('#app,#nv')) { e.preventDefault(); e.stopPropagation(); }
 }, true);
 document.addEventListener('change', e => {
  const s = ed && e.target.closest && e.target.closest('[data-edto]'); if (!s) return;
  const id = s.dataset.edto, v = s.value, m = (L().mvt || {})[id], casa = (m && m.f) || ed.t;
  muda(l => { l.mvt = Object.assign({}, l.mvt || {}); if (v === casa) delete l.mvt[id]; else l.mvt[id] = { f: casa, t: v }; }, '');
  if (window.mfToast && v !== ed.t) mfToast('O bloco vai para ' + nomeTela(v) + ' quando você tocar em Pronto');
 }, true);
 function mostra(id) { setTimeout(() => { const el = document.querySelector(`#app [data-bk$="|${id}"]`); if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 60); }

 /* ---------- arrastar ---------- */
 document.addEventListener('pointerdown', e => {
  if (!ed || e.button > 0) return;
  const b = e.target.closest && e.target.closest('#app .mf-ed-b');
  if (!b || e.target.closest('.mf-ed-ctl,select,input')) return;
  dg = { b, id: idDe(b), x: e.clientX, y: e.clientY, on: false, toque: e.pointerType !== 'mouse', tm: 0, alvo: null, depois: false };
  if (dg.toque) dg.tm = setTimeout(() => { if (dg) comeca(); }, 320);
 }, true);
 function comeca() { dg.on = true; dg.b.classList.add('mf-ed-drag'); document.documentElement.classList.add('mf-ed-arrasta'); try { navigator.vibrate && navigator.vibrate(12); } catch (_) { } }
 function limpaAlvo() { document.querySelectorAll('#app .mf-ed-antes,#app .mf-ed-depois').forEach(x => x.classList.remove('mf-ed-antes', 'mf-ed-depois')); }
 document.addEventListener('pointermove', e => {
  if (!dg) return;
  const dx = e.clientX - dg.x, dy = e.clientY - dg.y, dist = Math.hypot(dx, dy);
  if (!dg.on) {
   if (dg.toque) { if (dist > 8) { clearTimeout(dg.tm); dg = null; } return; }
   if (dist < 6) return; comeca();
  }
  e.preventDefault();
  dg.b.style.transform = `translate(${desk() ? dx : 0}px,${dy}px)`;
  dg.b.style.pointerEvents = 'none';
  const el = document.elementFromPoint(e.clientX, e.clientY), alvo = el && el.closest('#app .mf-ed-b');
  limpaAlvo(); dg.alvo = null;
  if (alvo && alvo !== dg.b) {
   const r = alvo.getBoundingClientRect(), lado = desk() && r.width < innerWidth * .45 ? e.clientX > r.left + r.width / 2 : e.clientY > r.top + r.height / 2;
   dg.alvo = idDe(alvo); dg.depois = lado; alvo.classList.add(lado ? 'mf-ed-depois' : 'mf-ed-antes');
  }
  if (e.clientY < 90) scrollBy(0, -14); else if (e.clientY > innerHeight - 140) scrollBy(0, 14);
 }, { capture: true, passive: false });
 document.addEventListener('touchmove', e => { if (dg && dg.on) e.preventDefault(); }, { capture: true, passive: false });
 const solta = () => {
  if (!dg) return;
  const g = dg; dg = null; clearTimeout(g.tm);
  if (!g.on) return;
  semClique = Date.now();
  g.b.style.transform = ''; g.b.style.pointerEvents = ''; g.b.classList.remove('mf-ed-drag');
  document.documentElement.classList.remove('mf-ed-arrasta'); limpaAlvo();
  if (g.alvo) poe(g.id, g.alvo, g.depois);
 };
 document.addEventListener('pointerup', solta, true);
 document.addEventListener('pointercancel', solta, true);

 /* ---------- folha "Adicionar blocos" ---------- */
 /* 1.18: abas pelas telas do app (Lançamentos, Planejamento, Dashboard, Investimentos, Análises).
    Em cada aba: os blocos novos daquela área e os blocos do app que foram escondidos com "−" naquela tela
    (ex.: "Saldo disponível hoje" escondido no Dashboard volta em Dashboard). A busca procura em todas as abas.
    Os blocos escondidos de todas as telas são lidos uma vez por abertura da folha (mfCollectBlocks, js/96). */
 let ocuCache = null;
 function ocultos() {
  if (ocuCache) return ocuCache;
  const out = [], gone = window.MF_INV_GONE || [];
  try {
   const T = window.mfCollectBlocks ? mfCollectBlocks() : {};
   Object.keys(T).forEach(t => T[t].forEach(([id, nm]) => {
    if (ehWg(id) || !isHid(id) || gone.includes(mfBase(id)) || out.some(x => x.id === id)) return;
    out.push({ id, t, nm: nm || id.replace(/^[a-z]+_/, '').replace(/_/g, ' ') });
   }));
  } catch (e) { console.warn('Editar tela: blocos ocultos', e); }
  return (ocuCache = out);
 }
 function abreSheet() {
  fechaSheet(); busca = ''; sheetSel = null; ocuCache = null;
  sheetAba = (window.MF_WG_AREAS || []).some(([k]) => k === ed.t) ? ed.t : 'res';
  const s = document.createElement('div'); s.id = 'mf-ed-sheet';
  s.innerHTML = `<div class="eds-fundo" data-edfecha="1"></div><div class="eds" role="dialog" aria-modal="true" aria-label="Adicionar blocos"><i class="eds-al" aria-hidden="true"></i><div class="eds-top"><b>Adicionar blocos</b><button type="button" class="eds-x" data-edfecha="1" aria-label="Fechar">×</button></div><label class="eds-busca"><input type="search" placeholder="Buscar bloco" data-edbusca="1" autocomplete="off"></label><div class="eds-seg" role="tablist"></div><div class="eds-g"></div></div>`;
  document.body.appendChild(s);
  pintaSheet();
  requestAnimationFrame(() => s.classList.add('on'));
 }
 function fechaSheet() { const s = document.getElementById('mf-ed-sheet'); if (s) s.remove(); sheetSel = null; ocuCache = null; }
 function pintaSheet() {
  const s = document.getElementById('mf-ed-sheet'); if (!s || !ed) return;
  const W = window.MF_WG || {}, pode = window.mfWgAqui ? mfWgAqui(ed.t) : false, q = busca.toLowerCase(), ach = x => !q || x.toLowerCase().includes(q);
  const O = ocultos(), areas = (window.MF_WG_AREAS || []).filter(([k]) => Object.keys(W).some(w => W[w].a === k) || O.some(x => x.t === k));
  if (!areas.some(([k]) => k === sheetAba) && areas.length) sheetAba = areas[0][0];
  const seg = s.querySelector('.eds-seg'), busc = s.querySelector('.eds-busca');
  seg.hidden = !!sheetSel || !!q; busc.hidden = !!sheetSel;
  seg.innerHTML = areas.map(([k]) => `<button type="button" role="tab" aria-selected="${sheetAba === k}" class="${sheetAba === k ? 'on' : ''}" data-edseg="${k}">${escH(nomeTela(k))}</button>`).join('');
  const g = s.querySelector('.eds-g');
  if (sheetSel && W[sheetSel.k]) { g.innerHTML = detalhe(sheetSel); g.scrollTop = 0; return; }
  const naAba = a => q ? true : a === sheetAba;
  const ks = !pode ? [] : Object.keys(W).filter(k => naAba(W[k].a) && ach(W[k].n));
  const wid = ks.map(k => { const w = W[k], nm = w.m.length; return `<div class="edw"><button type="button" class="edw-pv" data-edpick="${k}" aria-label="Ver ${escH(w.n)} em tamanhos e modelos">${mfWgSecao(k, 'm', '', mfWgExemplo(k), 'edw-card')}</button><b class="edw-n">${escH(w.n)}</b><small class="edw-d">${escH(w.d)}</small><small class="edw-m">${nm > 1 ? nm + ' modelos · ' : ''}${(window.MF_WG_SZ || []).length} tamanhos</small><div class="edw-bs"><button type="button" class="edw-b2" data-edpick="${k}">Personalizar</button><button type="button" class="edw-b" data-edaddk="${k}">Adicionar</button></div></div>`; });
  const ocu = O.filter(x => naAba(x.t) && ach(x.nm)).map(x => `<div class="edw"><div class="edw-pv"><section class="edw-card edw-oc"><h2>${escH(x.nm)}</h2><small class="mf-wg-s">Oculto em ${escH(nomeTela(x.t))}</small></section></div><b class="edw-n">${escH(x.nm)}</b><small class="edw-d">Bloco do app que você escondeu.</small><button type="button" class="edw-b" data-edshow="${escH(x.id)}" data-edshowt="${escH(x.t)}">Mostrar</button></div>`);
  const sub = pode && window.mfWgSub ? mfWgSub(ed.t) : '', subNome = sub ? ((((window.MF_SEGS || {})[ed.t] || []).find(x => x[0] === sub) || [])[1] || (sub === 'ano' ? 'Ano' : sub)) : '';
  const aviso = !pode && !ocu.length ? '<p class="eds-nota">Esta tela não recebe blocos novos.</p>' : sub ? `<p class="eds-nota">Os blocos novos entram em ${escH(nomeTela(ed.t))} › ${escH(subNome)}.</p>` : '';
  const itens = wid.concat(ocu);
  g.innerHTML = aviso + (itens.length ? `<div class="eds-grade">${itens.join('')}</div>` : (q ? '<p class="eds-nota">Nada encontrado.</p>' : (pode ? '<p class="eds-nota">Nenhum bloco nesta aba.</p>' : '')));
 }
 function detalhe(o) {
  const w = MF_WG[o.k], v = mfWgModelo(o.k, o.v), sz = mfWgSz(o.k, o.sz, v);
  return `<div class="eds-det"><button type="button" class="eds-volta" data-edvolta="1">‹ Blocos</button>
   <div class="eds-pvg eds-pv-${sz}" aria-hidden="true">${mfWgSecao(o.k, sz, v, mfWgExemplo(o.k, v, sz), 'eds-real')}</div>
   <b class="edw-n">${escH(w.n)}</b><small class="edw-d">${escH(w.d)} Prévia com números de exemplo.</small>
   <div class="eds-op"><small>Tamanho</small><div class="eds-ch" role="group" aria-label="Tamanho">${MF_WG_SZ.filter(([k]) => k !== 'x' || mfWgMiniOk(o.k, v)).map(([k, t]) => `<button type="button" class="${sz === k ? 'on' : ''}" aria-pressed="${sz === k}" data-edsz="${k}">${t}</button>`).join('')}</div></div>
   ${w.m.length > 1 ? `<div class="eds-op"><small>Modelo</small><div class="eds-ch" role="group" aria-label="Modelo">${w.m.map(([k, t]) => `<button type="button" class="${v === k ? 'on' : ''}" aria-pressed="${v === k}" data-edmod="${k}">${escH(t)}</button>`).join('')}</div></div>` : ''}
   <button type="button" class="edw-b eds-add" data-edaddk="${o.k}">Adicionar à tela</button></div>`;
 }
 document.addEventListener('input', e => { const i = e.target.closest && e.target.closest('[data-edbusca]'); if (!i) return; busca = i.value.trim(); pintaSheet(); }, true);
 document.addEventListener('keydown', e => { if (e.key !== 'Escape' || !ed) return; const sh = document.getElementById('mf-ed-sheet'); if (!sh) return; if (sheetSel) { sheetSel = null; pintaSheet(); } else fechaSheet(); }, true);
})();

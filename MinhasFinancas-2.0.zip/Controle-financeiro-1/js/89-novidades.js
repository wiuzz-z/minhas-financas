/* ===== 0.4 · Novidades da versão =====
   Único lugar para contar ao usuário o que mudou. A cada versão nova: troque `ver` e a lista `itens` (título, explicação).
   - A lista aparece em Configurações › Notificações.
   - Uma vez por versão, ao abrir o app, aparece o aviso "App atualizado" (mesmo estilo do aviso de fatura).
   - Enquanto a lista não for aberta, o acesso às Configurações mostra uma bolinha e a linha Notificações mostra "Novo".
   Guarda só duas marcas neste aparelho (localStorage): fin1_novaviso (aviso já mostrado) e fin1_novvisto (lista já aberta).
   Nenhum dado financeiro é lido ou alterado aqui. */
(function () {
  const NOV = window.MF_NOVIDADES = {
    ver: '2.0',
    itens: [
      ['Nova organização das telas (2.0)', 'Lançamentos agora tem Início, Lista, Diário e Resumo. Planejamento tem Cartão, Compromissos, Dívidas, Situação e Simular. Investir virou Patrimônio, com Resumo (patrimônio líquido), Patrimônio (seus bens), Investimentos (Posição, Proventos, Análises e, no celular, Radar) e Metas. A Distribuição 50/30/20 voltou ao Dashboard.'],
      ['Radar: Eventos e Notícias (1.21)', 'No celular, Investimentos › Radar ganhou Eventos (próximas datas-com e pagamentos, fatos relevantes, comunicados, assembleias e resultados entregues à CVM, com o documento original) e Notícias (manchetes dos seus ativos e da economia, com o link da matéria). Datas sempre com o nome: publicação, referência, data-com e pagamento.'],
      ['Radar com dados (1.20)', 'No celular, Investimentos › Radar agora mostra alertas dos seus ativos (resultados, dívida e margem, balanços reapresentados e quedas ou altas fortes no dia, sempre separados) com os números, as datas, a fonte e o link do documento na CVM. Em Oportunidades: critérios objetivos com os números e uma lista de observação com preço de interesse. Dados da Dados B3 (CVM) e do Yahoo, atualizados todo dia de manhã.'],
      ['Radar nos Investimentos (1.19)', 'No celular, nova subaba Radar em Investimentos, com quatro áreas: Monitoramento, Oportunidades, Eventos e Notícias. Por enquanto só a estrutura: as áreas ainda não recebem dados.'],
      ['Blocos por tela e muito mais opções (1.18)', 'No "+" do Editar tela as abas agora são as telas do app: Lançamentos, Planejamento, Dashboard, Investimentos e Análises. São 60 blocos, com o tamanho novo Mini, e eles entram na subaba que estiver aberta. Um bloco que você escondeu volta na aba da tela de onde saiu.'],
      ['Contas agora é Planejamento (1.18)', 'A tela Contas passou a se chamar Planejamento. O Número mágico mostra só quanto os proventos do mês compram; a lista por ativo virou um bloco que você pode adicionar.'],
      ['Valor com pontuação e lançamento mais limpo (1.18)', 'Ao digitar um valor, a pontuação aparece sozinha (1900 vira 1.900). O Layout de Lançamento tem 6 modelos mais limpos, entre eles o novo Cartão. Saiu o aviso de fatura que aparecia por cima da tela; ele continua no bloco Avisos.'],
      ['Novo visual no computador (1.17)', 'No computador, o app ganhou um visual mais profissional: barra lateral plana, topo compacto, painéis com borda fina, indicadores com ícone, tabelas de lançamentos e recorrentes, formulários e janelas retos. O celular continua igual.'],
      ['Mais blocos, em tamanhos e formatos (1.16)', 'No "+" do Editar tela agora há 18 blocos, separados por área (Visão geral, Contas e cartão, Gastos, Investimentos e Proventos). Toque em "Personalizar" para escolher o tamanho (Pequeno, Médio ou Grande) e o formato (número, lista, barras, rosca, linha ou anel) vendo a prévia. Depois dá para trocar tocando no bloco no Editar tela.'],
      ['Aparência mais fácil (1.16)', 'Layout de Lançamento com a prévia grande em cima e os modelos em miniatura. Barra principal e Atalhos do topo mostram como a barra fica: arraste pela alça para mudar a ordem e toque no olho para tirar ou pôr uma tela. Em Tema, a cor agora pinta o plano de fundo do app.'],
      ['Editar tela e novos blocos (1.15)', 'No fim de cada aba, "Editar tela": tire blocos no "−", arraste para mudar a ordem e toque no "+" para adicionar blocos novos (Saldo de hoje, Resultado do mês, Fatura, Próximos vencimentos e outros). Em Aparência › Layouts, escolha o estilo Padrão ou Compacto e veja na tela antes de aplicar.'],
      ['Ajustes (1.15)', 'Diário mais simples (quanto sobra até o dia escolhido); Meus ativos em Graham e Bazin mostra Ticker, Meu PM, Graham e Bazin; o Simulador de aporte fica em Posição; saíram Metas por classe e Desempenho da carteira.'],
      ['Recomendações mais limpas (1.12)', 'O bloco de recomendações na aba Análise ficou só de leitura (sem adicionar manualmente), com uma linha por ativo, e passou a ficar logo abaixo de Meus ativos · Graham e Bazin.'],
      ['Recomendações das casas de análise (1.11)', 'Na aba Análise, novo bloco só com os seus ativos: consenso dos analistas (preço-alvo médio, faixa e recomendação) buscado automaticamente e, por casa (XP, Itaú, Citi…), o preço-alvo e a data que você registrar.'],
      ['Proventos mais compactos e métodos explicados (1.10)', 'Em Proventos por ativo as linhas da lista ficaram mais juntas. Os botões "O que é método Bazin" e "O que é método Graham" agora ficam em Simular Graham e Bazin, abaixo do botão Calcular.'],
      ['Seis ajustes (1.9)', 'O dia de hoje fica no centro do calendário; saiu o botão Importar extrato do Novo lançamento; Proventos ano a ano ficou no fim da aba Proventos; Distribuição 50/30/20 sempre em lista; seletor de mês da Lista de compras alinhado; Contas abre em Geral e Investimentos em Resumo.'],
      ['Cores por aba e blocos mais limpos (1.8)', 'No celular, cada aba tem sua cor quando selecionada (Dashboard amarelo, Investimentos verde, Lançamentos branco, Contas vermelho, Análises azul), os blocos ficaram sem linha em volta e a cor ficou só nos pequenos detalhes (Pago, % da renda, Dinheiro, Vale-refeição e selo da fatura).'],
      ['Arrastar para o lado sem pulo de verdade (1.7)', 'Depois de trocar de subaba por arrasto, os cartões não descem e sobem mais: só o deslize lateral aparece.'],
      ['Arrastar para o lado sem tremer (1.6)', 'Ao arrastar entre as subabas, a página não pula mais para o topo se estiver rolada e o navegador não balança a tela com o movimento do dedo. Só o deslize lateral aparece.'],
      ['Arrastar para o lado sem pulo (1.3)', 'Ao arrastar entre as subabas, a tela não desce e sobe mais depois de trocar: a entrada é só um deslize lateral, sem balançar.'],
      ['Visual refinado (1.2)', 'No celular: setas mais finas, botões em pílula, títulos centralizados e Metas por classe mais claras. No computador: Investimentos, Avisos e Contas sem cartões esticados, busca sem corte e barra lateral alinhada.'],
      ['Investimentos mais enxuto (1.1)', 'Abas na ordem Resumo, Posição, Proventos e Análise. O Número mágico foi para o Resumo e a Análise ganhou os botões "O que é método Bazin", "O que é método Graham" e "Atualizar".'],
      ['Arrastar só entre subabas', 'Em Investimentos, Contas e Análises (Mês/Ano), arraste o dedo para o lado para trocar de subaba. As abas da barra de baixo agora trocam só pelo toque. A tela não "desce e sobe" mais ao arrastar.'],
      ['Liquid Glass mais fluido (0.9)', 'Ao trocar de aba, o vidro dos botões e dos cards não pisca mais.']
    ]
  };
  const ler = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const gravar = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
  const marca = () => document.documentElement.classList.toggle('mf-nov', ler('fin1_novvisto') !== NOV.ver);
  const fechar = () => { const w = document.getElementById('mf-note-nov'); if (w) { w.classList.remove('on'); setTimeout(() => w.remove(), 300); } };

  window.mfNovPendente = () => ler('fin1_novvisto') !== NOV.ver;
  window.mfNovVisto = () => { gravar('fin1_novvisto', NOV.ver); gravar('fin1_novaviso', NOV.ver); marca(); fechar(); };

  /* aviso "App atualizado": só com o app aberto de verdade (sem tela de bloqueio, sem outra janela por cima) */
  function livre() {
    const app = document.getElementById('app'), cfg = document.getElementById('mf-cfg');
    return !!(app && app.querySelector('[data-bk]')) && !document.documentElement.classList.contains('mf-locked') &&
      !document.getElementById('mf-note') && !(cfg && !cfg.hidden);
  }
  function aviso(n) {
    if (ler('fin1_novaviso') === NOV.ver || document.getElementById('mf-note-nov')) return;
    if (!livre()) { if (n < 20) setTimeout(() => aviso(n + 1), 3000); return; }
    gravar('fin1_novaviso', NOV.ver);
    const w = document.createElement('div');
    w.id = 'mf-note-nov'; w.className = 'mf-note nov'; w.setAttribute('role', 'status');
    w.innerHTML = '<span class="mf-note-i" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9Z"/><path d="M19 16v4M17 18h4"/></svg></span>' +
      '<div class="mf-note-b"><b>App atualizado · versão ' + NOV.ver + '</b><span>Veja o que mudou nesta atualização.</span>' +
      '<div class="mf-note-a"><button type="button" data-nov="ver">Ver novidades</button><button type="button" data-nov="ok">Ok</button></div></div>';
    w.addEventListener('click', e => {
      const b = e.target.closest('[data-nov]'); if (!b) return;
      e.preventDefault(); e.stopPropagation(); fechar();
      if (b.dataset.nov === 'ver' && window.mfCfgOpen) {
        mfCfgOpen('notif');
        setTimeout(() => { const el = document.getElementById('mfc-nov'); if (el) el.scrollIntoView({ block: 'start' }); }, 60);
      }
    });
    document.body.appendChild(w);
    requestAnimationFrame(() => w.classList.add('on'));
    setTimeout(fechar, 12000);
  }
  let pediu = false;
  (window.__mfAD = window.__mfAD || []).push(function () {
    try { marca(); if (!pediu) { pediu = true; setTimeout(() => aviso(0), 1600); } } catch (e) { }
  });
  marca();
})();

/* ===== Nova organização · Patrimônio ("o que eu tenho"): Resumo | Patrimônio (bens) | Investimentos | Metas =====
   Resumo: patrimônio líquido = bens + investimentos − dívidas (só leitura; investimentos = soma de "Meus ativos", dívidas = Planejamento › Dívidas).
   Patrimônio: bens cadastrados à mão em S.bens (criado só quando a pessoa cadastra o primeiro; quem não usa não tem nada novo salvo).
   Investimentos › Radar: fica em js/71-radar.js (só celular).
   Nada daqui cria, muda ou apaga lançamento, ativo, saldo ou dívida. Cálculos em js/domain/patrimonio.js; visual reaproveita css/91 (.mf-pl). */
(function () {
 'use strict';
 const H = s => escH(s);
 const bens = () => Array.isArray(S.bens) ? S.bens : [];
 const invTotal = () => (Array.isArray(S.inv) ? S.inv : []).reduce((s, a) => s + (+ivNow(a) || 0), 0);
 const mesAno = d => d ? d.slice(5, 7) + '/' + d.slice(0, 4) : '';

 /* ---------- Resumo ---------- */
 window.mfPatHtml = function () {
  const br = mfBensResumo(bens()), dv = window.mfDivResumo ? mfDivResumo(S.debts, TD) : { total: 0, n: 0 }, P = mfPatLiq(br.total, invTotal(), dv.total);
  const li = (t, v, sub, go, neg) => `<div class="mf-pl-row"><span>${t}<small>${sub}</small></span><b class="${neg && v > 0 ? 'bad' : ''}">${neg && v > 0 ? '− ' : ''}${R(v)}</b><button type="button" class="mf-pl-go" data-patgo="${go}" aria-label="Abrir ${H(t)}">›</button></div>`;
  const barra = P.tem > 0 ? `<div class="mf-pat-bar" role="img" aria-label="Bens ${P.pBens}% e investimentos ${P.pInv}%"><i class="b" style="width:${P.pBens}%"></i><i class="i" style="width:${P.pInv}%"></i></div>
   <div class="mf-pat-leg"><span><i class="b"></i>Bens ${P.pBens}%</span><span><i class="i"></i>Investimentos ${P.pInv}%</span></div>` : '';
  return B('p_pat') + `<section class="c mf-pl mf-pat"><h2>Patrimônio líquido</h2>
  <div class="mf-pat-hero"><b class="${P.liq < -0.005 ? 'bad' : ''}">${R(P.liq)}</b><small>bens + investimentos − dívidas</small></div>
  <div class="mf-pl-box">${li('Bens', P.bens, br.n ? `${br.n} ${br.n === 1 ? 'bem cadastrado' : 'bens cadastrados'}` : 'nenhum cadastrado', 'bens')}${li('Investimentos', P.inv, 'soma de Meus ativos', 'pos')}${li('Dívidas', P.div, dv.n ? `${dv.n} ${dv.n === 1 ? 'dívida' : 'dívidas'} em Planejamento` : 'nenhuma cadastrada', 'div', true)}</div>
  ${barra ? `<div class="mf-pl-lb">Distribuição do que você tem</div>${barra}` : ''}</section>`;
 };
 document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-patgo]'); if (!b) return;
  e.preventDefault(); e.stopPropagation(); const g = b.dataset.patgo;
  if (g === 'div') { tab = 'mais'; window.__ctMode = 'div'; }
  else { window.__invMode = g; try { localStorage.setItem('fin1_invmode', g); } catch (_) { } }
  window.__mfLastTab = null; draw(); scrollTo(0, 0);
 }, true);

 /* ---------- Patrimônio (bens) ---------- */
 function form(b) {
  b = b || {};
  const v = b.v ? (+b.v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '';
  return `<div class="mf-pl-form" data-bemform="${H(b.id || 'new')}"><div class="mf-pl-g">
  <label class="mf-pl-f"><small>Nome</small><input type="text" data-bemf="n" value="${H(b.n || '')}" placeholder="Ex.: Apartamento, Carro"></label>
  <label class="mf-pl-f"><small>Tipo</small><select data-bemf="tipo">${MF_BEM_TIPOS.map(([k, , um]) => `<option value="${k}"${(b.tipo || 'imovel') === k ? ' selected' : ''}>${um}</option>`).join('')}</select></label>
  <label class="mf-pl-f"><small>Valor atual</small><input type="text" inputmode="decimal" data-bemf="v" value="${H(v)}" placeholder="0,00"></label></div>
  <div class="mf-pl-acts"><button type="button" class="mf-pl-b on" data-bemsave="1">Salvar</button><button type="button" class="mf-pl-b" data-bemcancel="1">Cancelar</button></div></div>`;
 }
 window.mfBensHtml = function () {
  const ed = window.__bemEd || null, r = mfBensResumo(bens());
  const row = b => ed === b.id ? form(b) : `<div class="mf-pl-li"><div class="mf-pl-li-t"><span><b>${H(b.n)}</b>${b.at ? `<small>valor atualizado em ${mesAno(b.at)}</small>` : ''}</span><b>${R(b.v)}</b></div>
   <div class="mf-pl-acts"><button type="button" class="mf-pl-b" data-bemedit="${H(b.id)}">Atualizar valor</button><button type="button" class="mf-pl-b" data-bemdel="${H(b.id)}">Excluir</button></div></div>`;
  return B('p_bens') + `<section class="c mf-pl mf-bens"><h2>Bens</h2>
  <p class="mf-pl-nt">Imóveis, veículos e outros bens, com o valor atual que você informa. Não mexe nos lançamentos.</p>
  ${r.n ? `<div class="mf-pl-sum"><div><small>Total em bens</small><b>${R(r.total)}</b></div><div><small>Cadastrados</small><b>${r.n}</b></div></div>${r.tipos.map(t => `<div class="mf-pl-lb">${t.nome} · ${R(t.total)}</div>${t.itens.map(row).join('')}`).join('')}` : (ed === 'new' ? '' : '<p class="mf-empty">Nenhum bem cadastrado.</p>')}
  ${ed === 'new' ? form() : '<button type="button" class="mf-pl-add" data-bemnew="1">+ Cadastrar bem</button>'}</section>`;
 };
 const redraw = () => { window.__mfLastTab = null; draw(); };
 document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-bemnew],[data-bemedit],[data-bemsave],[data-bemcancel],[data-bemdel]'); if (!b) return;
  e.preventDefault(); e.stopPropagation(); const D = b.dataset;
  if (D.bemnew) { window.__bemEd = 'new'; redraw(); return; }
  if (D.bemedit) { window.__bemEd = D.bemedit; redraw(); return; }
  if (D.bemcancel) { window.__bemEd = null; redraw(); return; }
  if (D.bemsave) {
   const f = document.querySelector('#app [data-bemform]'); if (!f) return;
   const val = k => (f.querySelector(`[data-bemf="${k}"]`) || {}).value || '';
   const x = mfBemNorm({ id: f.dataset.bemform, n: val('n'), tipo: val('tipo'), v: mfNum(val('v')), at: TD });
   if (!val('n').trim()) { mfToast('Dê um nome para o bem.'); return; }
   if (!(x.v > 0)) { mfToast('Informe o valor atual.'); return; }
   if (!Array.isArray(S.bens)) S.bens = [];
   if (f.dataset.bemform === 'new') { x.id = 'bm' + Date.now().toString(36); S.bens.push(x); }
   else { const i = S.bens.findIndex(y => y && y.id === f.dataset.bemform); if (i < 0) return; S.bens[i] = x; }
   window.__bemEd = null; save(); redraw(); mfToast('Bem salvo ✓'); return;
  }
  const i = bens().findIndex(y => y && y.id === D.bemdel); if (i < 0) return;
  const bm = mfBemNorm(S.bens[i]);
  mfConfirm({ title: 'Excluir bem?', ok: 'Excluir', body: `<p class="mf-cf-sub">${H(bm.n)}</p><div class="mf-cf-v">${R(bm.v)}</div><p class="mf-cf-note">Sai do seu patrimônio. Seus lançamentos não mudam.</p>`, onOk: () => { S.bens.splice(i, 1); save(); redraw(); } });
 }, true);

})();

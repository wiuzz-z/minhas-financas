/* Configuração central do app (1.30 · Fase 3). Único lugar para versão e endereços/chaves PÚBLICAS.
   Para publicar uma nova versão, altere só `version` aqui.
   A chave abaixo é a "publishable" do Supabase: pública por desenho; a proteção real são as regras RLS do banco.
   Nunca coloque chave secreta (service_role) neste arquivo. */
window.MF_CONFIG=Object.freeze({
 version:'2.0',
 supabaseUrl:'https://xrzebzwajwcxikwphwnw.supabase.co',
 supabasePublishableKey:'sb_publishable_wEg5VaXbyD3v7tT-iju09w_iG9F8aLs',
 supabaseLibSrc:'js/vendor/supabase-2.118.0.js'
});

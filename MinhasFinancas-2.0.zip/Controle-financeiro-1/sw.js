/* Service worker — Controle Alpha
   · Abre na hora: a tela vem do cache e a versão nova é baixada em segundo plano (vale na próxima abertura, sem reinstalar o APK).
   · Funciona offline: app, TODOS os arquivos css/js da página, ícones e biblioteca do Supabase ficam guardados.
   · Versão (1.30): cada versão tem o seu cache e os arquivos vão com ?v=VERSÃO no index.html; a página nova só passa a valer
     depois que todos os arquivos dela foram guardados. Nunca mistura página nova com arquivo velho.
   · Para subir a versão use: node scripts/subir-versao.js X.Y  (muda config.js, este arquivo e os ?v= do index.html juntos)
   · Dados (Supabase) vão sempre pela rede; a sincronização é feita pelo app.
   · Background Sync: quando a internet volta, avisa o app aberto para enviar o que ficou pendente. */
const VER='2.0'; // igual a MF_CONFIG.version e aos ?v= do index.html (scripts/subir-versao.js)
const V='mf-'+VER;
const PRE=['/','/manifest.json','/icons/icon-192.png','/icons/apple-touch-icon.png','/icons/favicon-32.png'];
const okToCache=res=>!!res&&(res.ok||res.type==='opaque');

/* pré-carga: a página e TODOS os css/js que ela usa (lidos da própria página) são guardados juntos, antes deste serviço assumir.
   Se qualquer um falhar, a instalação falha e continua valendo a versão anterior (inteira). Ícones: melhor esforço. (A biblioteca do Supabase é local, js/vendor/, e entra com os demais arquivos.) */
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(async c=>{
 const res=await fetch('/',{cache:'reload'});if(!res.ok)throw new Error('página '+res.status);
 const html=await res.clone().text();
 const files=[...new Set([...html.matchAll(/(?:src|href)="((?:css|js)\/[^"]+)"/g)].map(m=>m[1]))];
 await Promise.all(files.map(u=>fetch(u,{cache:'reload'}).then(r=>{if(!r.ok)throw new Error(u+' '+r.status);return c.put(u,r)})));
 await Promise.all([c.put('/',res.clone()),c.put('/index.html',res)]);
 await Promise.all([
  ...PRE.filter(u=>u!=='/').map(u=>fetch(u,{cache:'reload'}).then(r=>{if(r.ok)return c.put(u,r)}).catch(()=>{}))
 ]);
}).then(()=>self.skipWaiting()))});

self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});

/* página: responde com a guardada na hora; busca a nova em paralelo e guarda para a próxima abertura.
   A guardada é copiada inteira antes de responder, para a gravação da nova não trocar o conteúdo no meio da leitura. */
function page(e){
 const old=caches.match('/index.html').then(h=>h||caches.match('/')).then(h=>h?h.blob().then(b=>new Response(b,{status:200,headers:h.headers})):null).catch(()=>null);
 const net=old.then(()=>fetch(e.request)).then(res=>{
  if(res&&res.ok&&!res.redirected&&/text\/html/.test(res.headers.get('content-type')||'')){const cp=res.clone();
   /* página de OUTRA versão não entra neste cache (os arquivos dela ainda não foram guardados): ela chega pela instalação do serviço novo */
   return cp.text().then(t=>{const v=[...t.matchAll(/(?:src|href)="(?:css|js)\/[^"?]+\?v=([^"]*)"/g)].map(m=>m[1]);return v.length&&v.every(x=>x===VER)?caches.open(V).then(c=>c.put('/index.html',res.clone())):null}).then(()=>res,()=>res)}
  return res});
 e.waitUntil(net.catch(()=>{}));
 return old.then(hit=>hit||net).catch(()=>Response.error())}

self.addEventListener('fetch',e=>{
 const r=e.request;if(r.method!=='GET')return;
 const u=new URL(r.url);
 if(u.hostname.endsWith('supabase.co'))return; // somente rede
 if(r.mode==='navigate'&&u.origin===location.origin&&(u.pathname==='/'||u.pathname==='/index.html')){e.respondWith(page(e));return}
 /* css/js com ?v=VERSÃO não mudam dentro da mesma versão: vêm do cache e NÃO são revistos na rede
    (rever deixaria o servidor de uma versão nova gravar arquivo novo no lugar do velho e misturar versões) */
 if(u.origin===location.origin&&u.searchParams.has('v')){e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{if(res&&res.ok){const cp=res.clone();e.waitUntil(caches.open(V).then(c=>c.put(r,cp)).catch(()=>{}))}return res})));return}
 const cacheable=u.origin===location.origin||/jsdelivr|cdnjs|unpkg|gstatic|googleapis/.test(u.hostname);
 if(!cacheable)return;
 /* arquivos: do cache na hora e atualiza em segundo plano */
 e.respondWith(caches.match(r).then(hit=>{
  const net=fetch(r).then(res=>{if(okToCache(res)){const cp=res.clone();e.waitUntil(caches.open(V).then(c=>c.put(r,cp)).catch(()=>{}))}return res}).catch(()=>hit||Response.error());
  if(hit)e.waitUntil(net.catch(()=>{}));
  return hit||net}))});

/* Background Sync: internet voltou → pede ao app aberto para enviar as alterações pendentes.
   Com o app fechado não há o que enviar daqui: os dados ficam no aparelho e sobem na próxima abertura. */
self.addEventListener('sync',e=>{if(e.tag!=='mf-sync')return;
 e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>cs.forEach(c=>c.postMessage({type:'mf-sync'}))))});

/* Avisos com o app fechado (enviados pelo Supabase) */
self.addEventListener('push',e=>{let d={};try{d=e.data?e.data.json():{}}catch(_){d={body:e.data?e.data.text():''}}
 e.waitUntil(self.registration.showNotification(d.title||'Controle Alpha',{body:d.body||'',tag:d.tag||'mf-aviso',icon:'/icons/icon-192.png',badge:'/icons/icon-192.png',data:{url:d.url||'./'}}))});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=new URL((e.notification.data&&e.notification.data.url)||'./',self.registration.scope).href;
 e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('navigate' in c&&'focus' in c)return c.navigate(url).then(w=>(w||c).focus())}return self.clients.openWindow(url)}))});
